from cdapython.constantVariables import CDA_API_URL

localhost = "http://localhost:8080"
production_host = CDA_API_URL
integration_host = "http://35.192.60.10:8080/"
host = integration_host

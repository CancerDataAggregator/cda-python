from cdapython import unique_terms

print(unique_terms("vital_status", version="all_v2_1"))

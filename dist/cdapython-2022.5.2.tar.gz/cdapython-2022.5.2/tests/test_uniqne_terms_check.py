from cdapython.utility import unique_terms


def test_unique_terms_convert():
    unique_terms("ResearchSubject.associated_project")
